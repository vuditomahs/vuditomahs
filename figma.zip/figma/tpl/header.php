<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./style/index.css">
    <title>Document</title>
</head>
<header>
    <div class="menu">
        <a href="#"><p class="menu_p" style="width: 48px">Home</p></a>
        <a href="#"><p class="menu_p" style="width: 47px">Pages</p></a>
        <a href="#"><p class="menu_p" style="width: 87px">Contact Us</p></a>
        <a href="#"><p class="menu_p" style="width: 35px">Blog</p></a>
        <a href="#"><p class="menu_p" style="width: 64px">Landing</p></a>
    </div>
    <div class="header">
        <div class="log">
            <div class="logo">
                <p class="logo_p">Gerícht</p>
            </div>
        </div>
    </div>
    <div class="header_p">
        <div class="logs">
            <div class="login">
                <p class="login_p">Log in / registration</p>
            </div>
        </div>
        <div class="line"></div>
        <div class="book">
            <p class="book_p">Book Table</p>
        </div>
    </div>
</header>
<body>

</body>
</html>
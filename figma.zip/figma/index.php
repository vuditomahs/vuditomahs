<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel='stylesheet' href='/style/index.css'/>
    <title>Restaurant Home</title>
</head>

<body>
    <?php
    include 'tpl/header.php';
    ?>
    <div class="hashtag">
        <p class="hashtag-p">#Gericht</p>
        <p class="hashtag-p">#Bar</p>
    </div>
    <div class="slider">
        <p class="slider-p">01</p>
        <p class="slider-line"></p>
        <p class="slider-p">02</p>
        <p class="slider-p">03</p>
        <p class="slider-p">04</p>
    </div>
    <div class="scroll">
        <p class="scroll-vector"></p>
        <p class="scroll-p">Scroll</p>
    </div>
    <div class="content">
    <div class="content1">
    <div class="content2">
    <div class="content3">
        <p class="content3-p">Chase the new Flavour</p>
    </div>
        <p class="content2-p">The key to Fine dining</p>
    </div>
        <p class="content1-p">Sit tellus lobortis sed senectus vivamus molestie. Condimentum volutpat morbi facilisis quam scelerisque sapien. Et, penatibus aliquam amet tellus </p>
    <div class="button">
        <p class="button-p">Explore Menu</p>
    </div>
    </div>
    <div class="hero-img">
    <div class="mask-group"><img src="photo/Hero img.png" alt=""></div>
    </div>
    </div>
    <!-- 2 страница -->
    <div class="about">
    <div class="about-content">
    <!-- <img class="about-img" src="photo/knife.png" alt=""> -->
    <div class="history">
    <div class="title">
        <p class="title-p">Our History</p>
        <p  class="title-p1">Adipiscing tempus ullamcorper lobortis odio tellus arcu volutpat. Risus placerat morbi volutpat habitasse interdum mi aliquam In sed odio nec aliquet.</p>
    <div class="button">
        <p class="button-p">Know more</p>
    </div>
    </div>
    </div>
    <img class="img-about" src="photo/knife.png" alt="">
    <div class="aboutus">
    <div class="title-about">
        <p class="title-about-p">About Us</p>
        <p  class="title-about-p1">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quis pharetra adipiscing ultrices vulputate posuere tristique. In sed odio nec aliquet eu proin mauris et.</p>
    <div class="button">
        <p class="button-p">Know more</p>
    </div>
    </div>
    </div>
    </div>
    </div>
    <!-- 3 страница -->
    <div class="reservation">
    <div class="title-reserv">
        <p class="title-reserv-p">Reservations</p>
        <p class="title-reserv-p1">Book A Table</p>
    </div>
    <div class="box">
    <div class="person">
    <div>
        <p>1 person</p>
    </div>
    </div>
    </div>
</div>
</body>
</html>